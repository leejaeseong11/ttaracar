import cv2
import numpy as np

accuracy = 0.0
return_homo = 0,0,0,0

def featureDetect(frame): #Feature Matching을 통한 사용자 재인식

    global accuracy , homography, x, y, w, h
    accuracy = 0.0
    return_homo = 0, 0, 0, 0

    MIN_MATCH = 10 #최소 매칭점 개수
    detector = cv2.ORB_create(1000) #최대 Feature 수 = 1000
    FLANN_INDEX_LSH = 6
    index_params = dict(algorithm=FLANN_INDEX_LSH,
                        table_number=6,
                        key_size=12,
                        multi_probe_level=1)
    search_params = dict(checks=32)
    matcher = cv2.FlannBasedMatcher(index_params, search_params)
    idx = 0 # 등록된 사용자와 매칭

    while idx<5:
        idx += 1
        #image 불러오기
        if idx == 1:
            img1 = cv2.imread(r"./user/face1.jpg", 1)
        if idx == 2:
            img1 = cv2.imread(r"./user/face2.jpg", 1)
        if idx == 3:
            img1 = cv2.imread(r"./user/face3.jpg", 1)
        if idx == 4:
            img1 = cv2.imread(r"./user/face4.jpg", 1)
            if img1 is None:
                img1 = cv2.imread(r"./user/face1.jpg", 1)

        img2 = frame

        # 흑백 변환
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

        # 키포인트와 디스크립터 추출
        kp1, desc1 = detector.detectAndCompute(gray1, None)
        kp2, desc2 = detector.detectAndCompute(gray2, None)

        # k=2로 knnMatch
        matches = matcher.knnMatch(desc1, desc2, 2)
        # 이웃 거리의 75%로 좋은 매칭점 추출---②
        ratio = 0.75
        good_matches = [m[0] for m in matches \
                        if len(m) == 2 and m[0].distance < m[1].distance * ratio]

        # 모든 매칭점 그리지 못하게 마스크를 0으로 채움
        matchesMask = np.zeros(len(good_matches)).tolist()

        # 좋은 매칭점 최소 갯수 이상 인 경우
        if len(good_matches) > MIN_MATCH:
            # 좋은 매칭점으로 원본과 대상 영상의 좌표 구하기 ---③
            src_pts = np.float32([kp1[m.queryIdx].pt for m in good_matches])
            dst_pts = np.float32([kp2[m.trainIdx].pt for m in good_matches])
            # 원근 변환 행렬 구하기 ---⑤
            mtrx, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
            accuracy = float(mask.sum()) / mask.size
            print("accuracy: %d/%d(%.2f%%)" % (mask.sum(), mask.size, accuracy))

            if mask.sum() > MIN_MATCH:  # 정상치 매칭점 최소 갯수 이상 인 경우
                # 이상점 매칭점만 그리게 마스크 설정
                matchesMask = mask.ravel().tolist()

                # 원본 영상 좌표로 원근 변환 후 영역 표시  ---⑦
                h, w, = img1.shape[:2]

                #if abs(h)<700 and abs(h)>0 and abs(w)>0 and abs(w)<700:
                pts = np.float32([[[0, 0]], [[0, h - 1]], [[w - 1, h - 1]], [[w - 1, 0]]])
                dst = cv2.perspectiveTransform(pts, mtrx)

                homography = cv2.boundingRect(dst)
                x, y, w, h = homography

                if 0< h < 700 and 0 < w < 700 and 0 < x < 700 and 0 < y < 700:
                    img2 = cv2.rectangle(img2, (x, y), (x + w, y + h), (255, 0, 0), 3)
                    return_homo = x,y,w,h

        if accuracy > 50: # 50% 이상이면 반복문 종료
            break

    return accuracy, return_homo

