# yolov4tiny
import time
import tensorflow as tf

physical_devices = tf.config.experimental.list_physical_devices('GPU')
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)
from absl import app, flags, logging
from absl.flags import FLAGS
import core.utils as utils
import core.FeatureDetectors as matching
from core.yolov4 import filter_boxes
from tensorflow.python.saved_model import tag_constants
from PIL import Image
import cv2
import numpy as np
import paho.mqtt.client as mqtt
from tensorflow.compat.v1 import ConfigProto
from tensorflow.compat.v1 import InteractiveSession

flags.DEFINE_string('framework', 'tf', '(tf, tflite, trt')
flags.DEFINE_string('weights', './checkpoints/yolov4-tiny-416',
                    'path to weights file')
flags.DEFINE_boolean('tiny', False, 'yolo or yolo-tiny')
flags.DEFINE_string('model', 'yolov4', 'yolo-tiny')
flags.DEFINE_integer('size', 416, 'resize images to')
flags.DEFINE_float('iou', 0.45, 'iou threshold')
flags.DEFINE_float('score', 0.25, 'score threshold')
flags.DEFINE_boolean('dont_show', False, 'dont show video output')

redetect_ok = False #재인식을 위한 조건 변수
isFirst = False  # YOLO를 이용해 사용자 인식하기 위한 조건변수

ok = True
motor_camera = ' '
buzzer = 'off'
mid = 0 #rectangle 중심좌표
#사용자 사진 저장을 위한 변수
front = False
left = False
right = False
idx = 1
LEFT = 1
RIGHT = 1
FRONT = 1
count = 0
def main(_argv):
    #MQTT 설정
    broker_address = "192.168.0.3"#"192.168.1.153"# #"192.168.0.4" #broker 주소(현재 소진 노트북) #
    client = mqtt.Client()
    config = ConfigProto()
    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.connect(broker_address, 1883)
    client.loop_start()
    client.on_message = on_message
    client.subscribe("Ready")
    client.subscribe("Cam")

    #Yolov4-tiny 설정
    config.gpu_options.allow_growth = True
    cv2.ocl.setUseOpenCL(False)
    session = InteractiveSession(config=config)
    STRIDES, ANCHORS, NUM_CLASS, XYSCALE = utils.load_config(FLAGS)
    input_size = FLAGS.size

    saved_model_loaded = tf.saved_model.load(FLAGS.weights, tags=[tag_constants.SERVING])
    infer = saved_model_loaded.signatures['serving_default']

    tracker = None # 초기 KCF Tracker는 None
    isDetect = False  # 재인식을 위한 조건변수

    # begin video capture
    try:
        vid = cv2.VideoCapture('http://192.168.0.3:8081/?action=stream') #motion web streaming

    except:
        print('error: empty camera!')

   # out = None
    global redetect_ok, ok, mid, motor_camera, buzzer, isFirst, front, left, right, idx, LEFT, RIGHT, FRONT, count

    while True:
        start_time = time.time() #FPS 계산
        return_value, frame = vid.read()

        if return_value:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image = Image.fromarray(frame)  # numpy배열을 Image객체로 바꿈

        else:
            print('Video has ended or failed, try a different video format!')
            break

        if isDetect: #Tracking(KCF)
            accuracy, homography = matching.featureDetect(frame)
            tracker.init(frame, homography)

            if (accuracy >= 0.6 and homography != 0,0,0,0): #60%일치하고, box좌표가 존재한다면
                redetect_ok, boxes = tracker.update(frame)  # 새로운 프레임에서 추적 위치 찾기
                (x, y, w, h) = boxes

                if redetect_ok and abs(x-w)<100 and abs(y-h)<200: #적당한 크기의 box일 경우
                    cv2.rectangle(frame, (int(x), int(y)), (int(x + w), int(y + h)), (255, 255, 255), 2, 1)
                    isDetect = False #재인식 종료
                    client.publish('buzzer', 'off') #buzzer 종료

                else:
                    isDetect = True
                    redetect_ok = False

        if isFirst: #YOLO로 사람 검출
            count += 1
            frame_size = frame.shape[:2]
            image_data = cv2.resize(frame, (input_size, input_size))
            image_data = image_data / 255.
            image_data = image_data[np.newaxis, ...].astype(np.float32)

            batch_data = tf.constant(image_data)
            pred_bbox = infer(batch_data)
            for key, value in pred_bbox.items():
                boxes = value[:, :, 0:4]
                pred_conf = value[:, :, 4:]

            boxes, scores, classes, valid_detections = tf.image.combined_non_max_suppression(
                boxes=tf.reshape(boxes, (tf.shape(boxes)[0], -1, 1, 4)),
                scores=tf.reshape(
                    pred_conf, (tf.shape(pred_conf)[0], -1, tf.shape(pred_conf)[-1])),
                max_output_size_per_class=50,
                max_total_size=50,
                iou_threshold=FLAGS.iou,
                score_threshold=FLAGS.score
            )

            pred_bbox = [boxes.numpy(), scores.numpy(), classes.numpy(), valid_detections.numpy()]
            roi = utils.detect_roi(frame, pred_bbox)
            (x, y, w, h) = roi #box 좌표

            tracker = cv2.TrackerKCF_create()  # 트래커 객체 생성
            if roi[2] and roi[3]:  # 위치 설정 값이 있는 경우
                tracker.init(frame, roi)  # Initialize tracker with first frame and bounding box
                user = frame[int(y)+15:int(h + y)-50, int(x)+10:int(w + x)-10]
                if FRONT is 1:
                    cv2.imwrite('./user/face1.jpg', user) #정면 사진 촬영
                    #time.sleep(3)
                    client.publish('OK','left')
                    FRONT *= 0

                if count >90:
                    if left == True and LEFT is 1:
                        cv2.imwrite('./user/face2.jpg', user) # 왼쪽 사진 촬영
                        #time.sleep(3)
                        client.publish('OK','right')
                        print('right 전송 완료')
                        LEFT *= 0
                        count = 0
                        continue
                    if right == True and RIGHT is 1:
                        cv2.imwrite('./user/face3.jpg', user) # 오른쪽 사진 촬영
                        #time.sleep(3)
                        print('사진 찍기 완료')
                        RIGHT *= 0
                        count = 0
                #if left == True and right == True:
                if LEFT is 0 and RIGHT is 0:
                    isFirst = False
            #isFirst = False # 사용자 등록 종료

        # tracker_kcf
        if tracker is None:  # 트래커가 생성 안 된 경우
            cv2.putText(frame, "Cannot detect person",
                        (100, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2, cv2.LINE_AA)
        else:
            #(x, y, h, w) = 0
            if ok:
                ok, boxes = tracker.update(frame)  # 새로운 프레임에서 추적 위치 찾기
                (x, y, w, h) = boxes
                #user = frame[int(y) + 15:int(h + y) - 50, int(x) + 10:int(w + x) - 10]
                #cv2.imwrite('./user/face4.jpg', user) # 사용자 모습 지속적으로 촬영 (최신 반영)
                print("ok")
                cv2.rectangle(frame, (int(x), int(y)), (int(x + w), int(y + h)), (0, 255, 0), 2, 1)
                mid = int(x + (w / 2))

            elif redetect_ok: #재인식
                redetect_ok, boxes = tracker.update(frame)  # 새로운 프레임에서 추적 위치 찾기
                (x, y, w, h) = boxes
                #user = frame[int(y) + 15:int(h + y) - 50, int(x) + 10:int(w + x) - 10]
                #cv2.imwrite('./user/face4.jpg', user) #사용자의 최신 모습 촬영 및 저장
                print('redetect')
                cv2.rectangle(frame, (int(x), int(y)), (int(x + w), int(y + h)), (0, 0, 255), 2, 1) #사각형 그리기
                mid = int(x + (w / 2)) #사각형의 중간 좌표

            else: #인식이 되지 않는 경우
                isDetect = True #재인식 실행
                tracker.clear() #Tracker 초기화
                tracker = cv2.TrackerKCF_create()  # 트래커 객체 생성
                cv2.putText(frame, "Tracking fail.", (100, 80),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2, cv2.LINE_AA)
                client.publish('buzzer','on') # 부저 실행을 위한 MQTT 값 전송

        if mid != 0: # box의 중간 좌표 값이 존재한다면
            user = frame[int(y) + 15:int(h + y) - 50, int(x) + 10:int(w + x) - 10]
            cv2.imwrite('./user/face4.jpg', user) # 사용자 모습 지속적으로 촬영 (최신 반영)
            if mid <= 100:
                motor_camera = 'big_left' #큰 좌회전
            elif mid <= 200:
                motor_camera = 'left' #좌회전
            elif mid >= 400:
                motor_camera = 'big_right' #큰 우회전
            elif mid >= 300:
                motor_camera = 'right' # 우회전
            else:
                motor_camera = 'straight' #직진
            client.publish('motor_camera',motor_camera) #사용자의 위치 MQTT로 전송

        fps = 1.0 / (time.time() - start_time) #FPS 계산
        cv2.putText(frame, "FPS: %.2f" % fps, (15, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 255), 1, cv2.LINE_AA)

        result = np.asarray(image)
        cv2.namedWindow("result", cv2.WINDOW_AUTOSIZE)
        result = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

        if not FLAGS.dont_show:
            cv2.imshow("result", result)

        if cv2.waitKey(1) & 0xFF == ord('q'): break

    cv2.destroyAllWindows() # 종료
    # MQTT 종료
    client.loop_stop()
    client.disconnect()
    client.loop_forever()

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected OK")
    else:
        print("Bad connection Returned code=", rc)

def on_disconnect(client, userdata, flags, rc=0):
    print(str(rc))


def on_message(client, userdata, message):
    global isFirst, front, left, right, idx
    print("Topic", message.topic, "data", message.payload)
    print(message.payload)
    if message.payload == b'ready': #start 버튼
        isFirst = True
    if message.payload == b'left_ok' and idx is 1: #왼쪽 사진 찍으라는 명령
        global left
        left = True
        print("left 받음")
        print(left, right)
        idx = 2
    if message.payload == b'right_ok' and idx is 2: #오른쪽 사진 찍으라는 명령
        right = True
        print("right 받음")




if __name__ == '__main__':
    try:
        app.run(main)
    except SystemExit:
        pass