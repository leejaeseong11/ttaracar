﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;


namespace ScreenGUI
{
    public partial class Cam_recog : Form
    {

        MqttClient client;
        string clientId;

        public Cam_recog()
        {
            InitializeComponent();

            label5.Visible = true; //시작 멘트
            label1.Visible = false; //정면 멘트
            label3.Visible = false; //왼쪽 멘트
            label4.Visible = false;

        }

        private void timer1_Tick(object sender, EventArgs e) {
            fn_prbar();
        }

        private void Startbtn_Click(object sender, EventArgs e)
        {
            label5.Hide(); //시작 멘트
            label1.Visible = true;//정면 멘트

            /****MQTT****/
            string BrokerAddress = "localhost";

            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            //client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();

            client.Connect(clientId);

            // publish a message on "/home/temperature" topic with QoS 2 
            client.Publish("Ready", Encoding.UTF8.GetBytes("ready"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);

            /****Progress Bar timer****/
            this.timer1.Enabled = true;
            this.Startbtn.Enabled = false;
            this.timer1.Tick += timer1_Tick;

            client.Subscribe(new string[] { "OK" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived; // register a callback-function

            /****Web Streaming VideoCapture****/
            videoCapture1.IP_Camera_Source = new VisioForge.Types.Sources.IPCameraSourceSettings() { URL = "http://192.168.0.3:8081/?action=stream", Type = VisioForge.Types.VFIPSource.Auto_LAV };
            videoCapture1.Audio_PlayAudio = videoCapture1.Audio_RecordAudio = false;
            videoCapture1.Mode = VisioForge.Types.VFVideoCaptureMode.IPPreview;
            videoCapture1.Video_Rotation = VisioForge.Types.VFRotateMode.Rotate180;

            videoCapture1.Start();

        }

        public void fn_prbar() {
            progressBar1.Increment(1);
            label2.Text = "진행중... " + progressBar1.Value.ToString() + "%";
            

            if (progressBar1.Value == progressBar1.Maximum) {
                timer1.Stop();
                MessageBox.Show("인식에 성공했습니다.");
                this.Close();
                timer1.Stop();

                Buzzer_test buzzer_Test = new Buzzer_test();
                buzzer_Test.Show();

                client.Disconnect();
            }
        }

        // this code runs when a message was received
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            
            if (ReceivedMessage == "left") {


                label1.Invoke((MethodInvoker)delegate ()
               {
                   label1.Visible = false;
               });

                label3.Invoke((MethodInvoker)delegate ()
                {
                    label3.Visible = true;
                });

                label4.Invoke((MethodInvoker)delegate ()
                {
                    label4.Visible = false;
                });


                client.Publish("Cam", Encoding.UTF8.GetBytes("left_ok"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
            }

            else if (ReceivedMessage == "right"){

                label4.Invoke((MethodInvoker)delegate ()
                {
                    label4.Visible = true;
                });

                label3.Invoke((MethodInvoker)delegate ()
                {
                    label3.Visible = false;
                });


                client.Publish("Cam", Encoding.UTF8.GetBytes("right_ok"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
            }
        }

  
    }
}
