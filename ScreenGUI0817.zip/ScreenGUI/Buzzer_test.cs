﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace ScreenGUI
{
    public partial class Buzzer_test : Form
    {

        MqttClient client;
        string clientId;

        public Buzzer_test()
        {
            InitializeComponent();

            button3.Hide();
            button2.Show();

            string BrokerAddress = "localhost";

            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            //client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();

            client.Connect(clientId);


        }

        // this code runs when the button "소리 테스트하기" is clicked
        private void button2_Click(object sender, EventArgs e)
        {
            // publish a message on "/buzzer/test" topic with QoS 2 
            client.Publish("buzzer", Encoding.UTF8.GetBytes("on"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);

            button2.Hide();
            button3.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Disconnect();

            base.OnClosed(e);
            //App.Current.Shutdown();

            this.Close();
            Automode automode = new Automode();
            automode.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // publish a message on "/buzzer/test" topic with QoS 2 
            client.Publish("buzzer", Encoding.UTF8.GetBytes("off"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);

            button3.Hide();
            button2.Show();
        }
    }
}



 
