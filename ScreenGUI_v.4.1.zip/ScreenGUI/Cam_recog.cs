﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;


namespace ScreenGUI
{
    public partial class Cam_recog : Form
    {

        MqttClient client;
        string clientId;

        public Cam_recog()
        {
            InitializeComponent();

            pictureBox1.Visible = true; //시작 멘트
            pictureBox4.Visible = true; //정면 멘트
            pictureBox3.Visible = true; //왼쪽 멘트
            pictureBox2.Visible = true; //오른쪽 멘트

            pictureBox4.Visible = false; //정면 멘트
            pictureBox3.Visible = false; //왼쪽 멘트
            pictureBox2.Visible = false; //오른쪽 멘트

        }

        private void timer1_Tick(object sender, EventArgs e) {
            fn_prbar();
        }

        private void Startbtn_Click(object sender, EventArgs e)
        {
            pictureBox1.Hide(); //시작 멘트
            pictureBox4.Visible = true;//정면 멘트

            /****MQTT****/
            string BrokerAddress = "localhost";

            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            //client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();

            client.Connect(clientId);

            // publish a message on "/home/temperature" topic with QoS 2 
            client.Publish("Ready", Encoding.UTF8.GetBytes("ready"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);

            /****Progress Bar timer****/
            this.timer1.Enabled = true;
            this.Startbtn.Enabled = false;
            this.timer1.Tick += timer1_Tick;

            client.Subscribe(new string[] { "OK" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived; // register a callback-function

        }

        public void fn_prbar() {
            progressBar1.Increment(1);
            label2.Text = "진행중... " + progressBar1.Value.ToString() + "%";
            

            if (progressBar1.Value == progressBar1.Maximum) {
                timer1.Stop();
                this.Close();
                timer1.Stop();

                Buzzer_test buzzer_Test = new Buzzer_test();
                buzzer_Test.Show();

                client.Disconnect();
            }
        }

        // this code runs when a message was received
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);

            
            if (ReceivedMessage == "left") {

                pictureBox4.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox4.Visible = true;
                    pictureBox4.Refresh();
                    pictureBox4.Visible = false;
                });

                pictureBox3.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox3.Refresh();
                    pictureBox3.Visible = true;
                });

                client.Publish("Cam", Encoding.UTF8.GetBytes("left_ok"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
            }

            else if (ReceivedMessage == "right"){

                pictureBox3.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox3.Visible = true;
                    pictureBox3.Refresh();
                    pictureBox3.Visible = false;
                });

                pictureBox2.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox2.Refresh();
                    pictureBox2.Visible = true;
                });

          

                client.Publish("Cam", Encoding.UTF8.GetBytes("right_ok"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
            }
        }
    }
}
