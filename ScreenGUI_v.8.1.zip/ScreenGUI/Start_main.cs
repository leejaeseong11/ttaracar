﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace ScreenGUI
{
    public partial class Start_main : Form
    {

        MqttClient client;
        string clientId;

        public Start_main()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /****MQTT****/
            string BrokerAddress = "localhost";

            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            //client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();

            client.Connect(clientId);

            // publish a message on "/home/temperature" topic with QoS 2 
            client.Publish("Ready", Encoding.UTF8.GetBytes("ready"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);

            Cam_recog cam_Recog = new Cam_recog();
            cam_Recog.Show();
            ///this.Hide(); 

        }

        private void Start_main_Load(object sender, EventArgs e)
        {

        }
    }
}
