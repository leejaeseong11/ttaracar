﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace ScreenGUI
{
    public partial class Cam_recog : Form
    {
        public Cam_recog()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e) {
            fn_prbar();
        }

        private void Startbtn_Click(object sender, EventArgs e)
        {
            this.timer1.Enabled = true;
            this.Startbtn.Enabled = false;
            this.timer1.Tick += timer1_Tick;
        }

        public void fn_prbar() {
            progressBar1.Increment(1);
            label2.Text = "진행중... " + progressBar1.Value.ToString() + "%";
            if (progressBar1.Value == progressBar1.Maximum) {
                timer1.Stop();
                MessageBox.Show("인식에 성공했습니다.");
                this.Close();
                timer1.Stop();

                Buzzer_test buzzer_Test = new Buzzer_test();
                buzzer_Test.Show();
            }
        }


    }
}
