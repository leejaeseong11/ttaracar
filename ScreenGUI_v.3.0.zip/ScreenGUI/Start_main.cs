﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenGUI
{
    public partial class Start_main : Form
    {
        public Start_main()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cam_recog cam_Recog = new Cam_recog();
            cam_Recog.Show();
            ///this.Hide(); 

        }

        private void Start_main_Load(object sender, EventArgs e)
        {

        }
    }
}
