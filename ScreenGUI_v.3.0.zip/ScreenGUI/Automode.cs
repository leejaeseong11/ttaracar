﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;

namespace ScreenGUI
{
    public partial class Automode : Form
    {

        MqttClient client;
        string clientId;

        
        public Automode()
        {
            InitializeComponent();

            pictureBox3.Visible = true;
            pictureBox2.Visible = false;
            pictureBox1.Visible = false;

            /****MQTT****/
            string BrokerAddress = "localhost";

            client = new MqttClient(BrokerAddress);

            // register a callback-function (we have to implement, see below) which is called by the library when a message was received
            //client.MqttMsgPublishReceived += client_MqttMsgPublishReceived;

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();

            client.Connect(clientId);

            // publish a message on "/home/temperature" topic with QoS 2 
            client.Publish("/auto/mode", Encoding.UTF8.GetBytes("auto mode"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);

            client.Subscribe(new string[] { "buzzer" }, new byte[] { MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE });
            client.MqttMsgPublishReceived += client_MqttMsgPublishReceived; // register a callback-function

          

        }

        private void Manualbtn_Click(object sender, EventArgs e)
        {
         
            client.Disconnect();
            base.OnClosed(e);

            Manualmode manualmode = new Manualmode();
            manualmode.Show();

            this.Hide();
        }

        private void Terminatebtn_Click(object sender, EventArgs e)
        {
    

            client.Disconnect();
            base.OnClosed(e);

            string BrokerAddress = "localhost";

            client = new MqttClient(BrokerAddress);

            // use a unique id as client id, each time we start the application
            clientId = Guid.NewGuid().ToString();

            client.Connect(clientId);

            client.Publish("/termination/mode", Encoding.UTF8.GetBytes("termination mode"), MqttMsgBase.QOS_LEVEL_EXACTLY_ONCE, false);
            this.Close();

        }

        private void Automode_Load(object sender, EventArgs e)
        {

        }

        // this code runs when a message was received
        void client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            string ReceivedMessage = Encoding.UTF8.GetString(e.Message);


            if (ReceivedMessage == "on")
            {

                pictureBox3.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox3.Refresh();
                    pictureBox3.Visible = false;
                });

                pictureBox2.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox2.Refresh();
                    pictureBox2.Visible = true;
                });

                pictureBox1.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox1.Refresh();
                    pictureBox1.Visible = true;
                });


            }

            else {

                pictureBox3.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox3.Refresh();
                    pictureBox3.Visible = true;
                });

                pictureBox2.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox2.Refresh();
                    pictureBox2.Visible = false;
                });

                pictureBox1.Invoke((MethodInvoker)delegate ()
                {
                    pictureBox1.Refresh();
                    pictureBox1.Visible = false;
                });

            }

        }

    }
}
