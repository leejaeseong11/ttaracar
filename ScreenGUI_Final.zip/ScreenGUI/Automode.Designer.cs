﻿namespace ScreenGUI
{
    partial class Automode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Terminatebtn = new System.Windows.Forms.Button();
            this.Manualbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("함초롬돋움", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Image = global::ScreenGUI.Properties.Resources.움직여주세요1;
            this.label2.Location = new System.Drawing.Point(139, 255);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(855, 72);
            this.label2.TabIndex = 9;
            this.label2.Text = "       ";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("함초롬돋움", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Image = global::ScreenGUI.Properties.Resources.카트가따라1;
            this.label3.Location = new System.Drawing.Point(200, 224);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(681, 70);
            this.label3.TabIndex = 8;
            this.label3.Text = "                                                                                 " +
    "              ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("함초롬돋움", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Image = global::ScreenGUI.Properties.Resources.인식못하고;
            this.label1.Location = new System.Drawing.Point(124, 199);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(882, 56);
            this.label1.TabIndex = 2;
            this.label1.Text = "                                                                  ";
            // 
            // Terminatebtn
            // 
            this.Terminatebtn.BackColor = System.Drawing.Color.DimGray;
            this.Terminatebtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Terminatebtn.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Terminatebtn.ForeColor = System.Drawing.Color.White;
            this.Terminatebtn.Image = global::ScreenGUI.Properties.Resources.termination_btn;
            this.Terminatebtn.Location = new System.Drawing.Point(793, 406);
            this.Terminatebtn.Name = "Terminatebtn";
            this.Terminatebtn.Size = new System.Drawing.Size(155, 95);
            this.Terminatebtn.TabIndex = 1;
            this.Terminatebtn.UseVisualStyleBackColor = false;
            this.Terminatebtn.Click += new System.EventHandler(this.Terminatebtn_Click);
            // 
            // Manualbtn
            // 
            this.Manualbtn.BackColor = System.Drawing.Color.DimGray;
            this.Manualbtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Manualbtn.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Manualbtn.ForeColor = System.Drawing.Color.White;
            this.Manualbtn.Image = global::ScreenGUI.Properties.Resources.manual_btn;
            this.Manualbtn.Location = new System.Drawing.Point(60, 406);
            this.Manualbtn.Name = "Manualbtn";
            this.Manualbtn.Size = new System.Drawing.Size(195, 95);
            this.Manualbtn.TabIndex = 0;
            this.Manualbtn.UseVisualStyleBackColor = false;
            this.Manualbtn.Click += new System.EventHandler(this.Manualbtn_Click);
            // 
            // Automode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1006, 553);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Terminatebtn);
            this.Controls.Add(this.Manualbtn);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Automode";
            this.ShowIcon = false;
            this.Text = "따라카";
            this.Load += new System.EventHandler(this.Automode_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Manualbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Terminatebtn;
    }
}